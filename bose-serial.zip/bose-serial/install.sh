#!/bin/bash
# Minimal install script for Volumio plugin
exit 0
